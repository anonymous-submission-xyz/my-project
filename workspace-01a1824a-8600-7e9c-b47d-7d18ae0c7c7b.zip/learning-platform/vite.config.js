import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import monacoEditorModule from 'vite-plugin-monaco-editor';

// Плагин — CJS с exports.default. Форма default-импорта зависит от бандлера
// конфига Vite (esbuild/oxc), поэтому достаём функцию защитно.
const monacoEditorPlugin =
  typeof monacoEditorModule === 'function'
    ? monacoEditorModule
    : monacoEditorModule.default;

// https://vite.dev/config/
export default defineConfig(({ command }) => ({
  // В сборке — относительные пути, чтобы статика работала из любой директории
  // (GitHub Pages project pages, открытие dist/index.html напрямую).
  // В dev Vite всё равно обслуживает приложение с '/', поэтому база разная.
  base: command === 'build' ? './' : '/',
  server: {
    // Vite 8 отклоняет запросы с неизвестным Host (403). Песочница Arena
    // проксирует превью через поддомены *.e2b.app — разрешаем их.
    allowedHosts: ['.e2b.app'],
  },
  plugins: [
    vue(),
    // Для Python нужны только подсветка и базовый воркер редактора.
    // Языковые воркеры TS/CSS/HTML/JSON исключаем — экономим размер сборки.
    // ВАЖНО: плагин требует esbuild в devDependencies — Vite 8 больше не
    // притаскивает esbuild сам (перешёл на Rolldown), а без него плагин падает
    // при импорте. Версия esbuild удовлетворяет optional-peer vite (^0.27 || ^0.28).
    monacoEditorPlugin({
      languageWorkers: ['editorWorkerService'],
    }),
  ],
}));
